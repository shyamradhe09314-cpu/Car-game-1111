
Car vs Car — 3 Lanes (Two‑Player)
==================================

Files:
  • index.html  — full game (mobile + desktop controls)
  • README.txt  — how to publish on GitHub Pages

How to publish (GitHub Pages — Free & Permanent):
1) Create a free GitHub account at https://github.com (if you don't have one).
2) New Repository → name it: car-vs-car-3lane (Public).
3) Upload index.html (drag & drop) → Commit changes.
4) Go to: Settings → Pages →
   • Source: Branch = main, Folder = /(root) → Save.
5) Wait ~30–60 seconds, you'll get a link like:
   https://YOUR-USERNAME.github.io/car-vs-car-3lane/
6) Share that link — it will work forever (until you delete the repo).

Controls:
  • Player A: A/D = change lane, W/S = speed ±
  • Player B: J/L = change lane, I/K = speed ±
  • Touch buttons also included for phones.
  • Collision on same lane ends the run; press Restart to play again.
